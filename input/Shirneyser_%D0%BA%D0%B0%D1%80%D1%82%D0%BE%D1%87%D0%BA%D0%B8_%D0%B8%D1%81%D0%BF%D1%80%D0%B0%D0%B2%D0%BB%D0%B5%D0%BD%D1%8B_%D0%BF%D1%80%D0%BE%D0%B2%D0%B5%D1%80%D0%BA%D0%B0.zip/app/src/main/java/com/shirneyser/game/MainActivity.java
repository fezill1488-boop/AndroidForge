package com.shirneyser.game;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int GOOGLE_SIGN_IN_REQUEST = 1002;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private GoogleSignInOptions googleOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        // The Google Services Gradle plugin supplies the real web client id.
        googleOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        int clientIdRes = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (clientIdRes != 0) {
            googleOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(clientIdRes))
                    .requestEmail()
                    .build();
        }

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                              FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startGoogleSignIn() {
        try {
            Intent signInIntent = GoogleSignIn.getClient(this, googleOptions).getSignInIntent();
            startActivityForResult(signInIntent, GOOGLE_SIGN_IN_REQUEST);
        } catch (Exception e) {
            callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote("Не удалось открыть Google-вход") + ")");
        }
    }

    private void finishGoogleLogin(GoogleSignInAccount account) {
        if (account == null || account.getIdToken() == null) {
            callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote("Google не вернул токен. Проверь SHA-1 в Firebase.") + ")");
            return;
        }
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (!task.isSuccessful() || firebaseAuth.getCurrentUser() == null) {
                String msg = task.getException() == null ? "Ошибка входа" : task.getException().getMessage();
                callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote(msg) + ")");
                return;
            }
            String uid = firebaseAuth.getCurrentUser().getUid();
            String name = firebaseAuth.getCurrentUser().getDisplayName() == null ? "" : firebaseAuth.getCurrentUser().getDisplayName();
            String email = firebaseAuth.getCurrentUser().getEmail() == null ? "" : firebaseAuth.getCurrentUser().getEmail();
            callJs("window.onCloudUser && window.onCloudUser(" +
                    JSONObject.quote(name) + "," + JSONObject.quote(email) + ")");
            loadCloud(uid);
        });
    }

    private void loadCloud(String uid) {
        firestore.collection("users").document(uid).get().addOnCompleteListener(this, task -> {
            if (!task.isSuccessful() || task.getResult() == null || !task.getResult().exists()) {
                callJs("window.onCloudLoaded && window.onCloudLoaded(false)");
                return;
            }
            String state = task.getResult().getString("localStorage");
            if (state == null) {
                callJs("window.onCloudLoaded && window.onCloudLoaded(false)");
                return;
            }
            callJs("window.onCloudState && window.onCloudState(" + JSONObject.quote(state) + ")");
        });
    }

    private void saveCloud(String state) {
        if (firebaseAuth.getCurrentUser() == null) {
            callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote("Сначала войди через Google") + ")");
            return;
        }
        String uid = firebaseAuth.getCurrentUser().getUid();
        Map<String, Object> data = new HashMap<>();
        data.put("localStorage", state);
        data.put("updatedAt", System.currentTimeMillis());
        data.put("email", firebaseAuth.getCurrentUser().getEmail());
        data.put("displayName", firebaseAuth.getCurrentUser().getDisplayName());
        firestore.collection("users").document(uid).set(data)
                .addOnSuccessListener(v -> callJs("window.onCloudSaved && window.onCloudSaved()"))
                .addOnFailureListener(e -> callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote(e.getMessage()) + ")"));
    }

    private void callJs(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("javascript:" + script, null);
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void signInWithGoogle() {
            runOnUiThread(MainActivity.this::startGoogleSignIn);
        }

        @JavascriptInterface
        public void saveCloud(String state) {
            runOnUiThread(() -> MainActivity.this.saveCloud(state));
        }

        @JavascriptInterface
        public void loadCloud() {
            if (firebaseAuth.getCurrentUser() != null) {
                MainActivity.this.loadCloud(firebaseAuth.getCurrentUser().getUid());
            }
        }

        @JavascriptInterface
        public boolean isGoogleSignedIn() {
            return firebaseAuth.getCurrentUser() != null;
        }

        @JavascriptInterface
        public String googleEmail() {
            return firebaseAuth.getCurrentUser() == null ? "" :
                    (firebaseAuth.getCurrentUser().getEmail() == null ? "" : firebaseAuth.getCurrentUser().getEmail());
        }

        @JavascriptInterface
        public void signOutGoogle() {
            firebaseAuth.signOut();
            GoogleSignIn.getClient(MainActivity.this, googleOptions).signOut();
            callJs("window.onCloudSignedOut && window.onCloudSignedOut()");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        } else if (requestCode == GOOGLE_SIGN_IN_REQUEST) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                finishGoogleLogin(account);
            } catch (ApiException e) {
                callJs("window.onCloudError && window.onCloudError(" + JSONObject.quote("Google-вход отменён или недоступен. Код: " + e.getStatusCode()) + ")");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
