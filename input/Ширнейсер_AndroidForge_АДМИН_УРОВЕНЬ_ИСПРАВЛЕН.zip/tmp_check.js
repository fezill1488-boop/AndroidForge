
const ADMIN_PASSWORD='МусорДроп';
const CASES={
 school:{key:'school',name:'Школьная Братва',price:99,src:'assets/egorova-family.jpg',cls:'school-name',items:[
  {name:'Егор в тумане',rarity:'Комонка',price:49,chance:10,src:'assets/egor-v-tumane.jpg',cls:'common'},
  {name:'Князь',rarity:'Эпик',price:79,chance:13,src:'assets/knyaz.jpg',cls:'epic'},
  {name:'Димас Мотоцикл',rarity:'Мифик',price:250,chance:5,src:'assets/dimas-moto.jpg',cls:'mythic'},
  {name:'Егор Спортсмен',rarity:'Легендарная',price:10000,chance:.1,src:'assets/egor-sportsman.jpg',cls:'legendary'},
  {name:'Дедушка Барбос',rarity:'Эпик',price:125,chance:8,src:'assets/dedushka-barbos.jpg',cls:'epic'},
  {name:'Сюсик',rarity:'Мифик',price:800,chance:2,src:'assets/syusik.jpg',cls:'mythic'},
  {name:'Птбайкер',rarity:'Легендарная',price:15000,chance:.1,src:'assets/ptbiker.jpg',cls:'legendary'},
  {name:'Шама Брат',rarity:'Легендарная',price:7777,chance:.5,src:'assets/shama-brat.jpg',cls:'legendary'},
  {name:'Надюшка',rarity:'Комонка',price:67,chance:9,src:'assets/nadushka.jpg',cls:'common'},
  {name:'Макарик',rarity:'Эпик',price:167,chance:15,src:'assets/makarik.jpg',cls:'epic'}]},
 admin:{key:'admin',name:'Админский Кейс',price:1000000,src:'assets/admin-case.jpg',cls:'admin-name',items:[
  {name:'Барбос Боль',rarity:'Легендарная',price:29000000,chance:.01,src:'assets/barbos-bol.jpg',cls:'legendary'},
  {name:'Крутой Шама',rarity:'Комонка',price:753670,chance:19,src:'assets/krutoy-shama.jpg',cls:'common'}]},
 dvor:{key:'dvor',name:'Кейс Барбоса',price:125000,src:'assets/dvorovskaya-zhizn.jpg',cls:'barbos-name',items:[
  {name:'Барбос Шляпник',rarity:'Комонка',price:25000,chance:20,src:'assets/barbos-shlyapnik.jpg',cls:'common'},
  {name:'Весёлый Барбос',rarity:'Эпик',price:135000,chance:4,src:'assets/vesely-barbos.jpg',cls:'epic'},
  {name:'Смешной Барбос',rarity:'Мифик',price:200000,chance:2,src:'assets/smeshnoi-barbos.jpg',cls:'mythic'},
  {name:'Барбос Ждун',rarity:'Комонка',price:20000,chance:18,src:'assets/barbos-zhdun.jpg',cls:'common'}]},
 makana:{key:'makana',name:'Кейс Макана',price:500000,src:'assets/case-makana.jpg',cls:'makana-name',items:[
  {name:'Умный Макар',rarity:'Мифик',price:600000,chance:1,src:'assets/umnyi-makar.jpg',cls:'mythic'},
  {name:'Всадник Макар',rarity:'Комонка',price:300000,chance:20,src:'assets/vsadnik-makar.jpg',cls:'common'},
  {name:'Макар Патриот',rarity:'Легендарка',price:1000000,chance:.001,src:'assets/makar-patriot.jpg',cls:'legendary'},
  {name:'Учёны1',rarity:'Эпик',price:450000,chance:30,src:'assets/ucheny1.jpg',cls:'epic'}]}
};
const gifts=[500,2500,10000,15000,20000,50000,100000];
const questPool=[{id:'open15',title:'Открыть 15 кейсов',reward:25000,target:15},{id:'mythic',title:'Выбить 1 мифик',reward:20000,target:1},{id:'legendary',title:'Выбить 1 легендарку',reward:50000,target:1},{id:'login',title:'Зайти в игру',reward:5000,target:1},{id:'school',title:'Открыть кейс «Школьная Братва»',reward:1488,target:1},{id:'dvor',title:'Открыть кейс «Кейс Барбоса»',reward:15000,target:1}];
const nicknames=['Шама','Барбос','Егор','Птбайкер','Тёмка Админ'];
const multipliers={5:6,10:5,30:4,50:2,75:1.5};
let profile=JSON.parse(localStorage.getItem('shirneyser_profile_v5')||'null');
let inventory=JSON.parse(localStorage.getItem('shirneyser_inventory_v5')||'[]');
let history=JSON.parse(localStorage.getItem('shirneyser_history_v5')||'[]');
let balance=Number(localStorage.getItem('shirneyser_balance_v5')||5000);
let totalExp=Number(localStorage.getItem('shirneyser_exp_v5')||0);
let stats=JSON.parse(localStorage.getItem('shirneyser_stats_v5')||'{"cases":0,"spent":0,"received":0}');
let adminAlwaysWin=localStorage.getItem('shirneyser_admin_always_win')==='1';
let openCount=1,currentCaseKey='school',selectedUpgradeId=null,upgradeChance=50,openingBusy=false,currentOpenCost=0,lightningFast=false,pendingUpgradeWin=null;
const inv=document.querySelector('#inv'),modal=document.querySelector('#openModal'),reels=document.querySelector('#reels'),results=document.querySelector('#results'),music=document.querySelector('#musicAudio');
function ensureInventoryIds(){let changed=false;inventory.forEach((x,i)=>{if(!x.id){x.id='legacy_'+Date.now()+'_'+i+'_'+Math.random().toString(36).slice(2);changed=true}});if(changed)localStorage.setItem('shirneyser_inventory_v5',JSON.stringify(inventory));}
ensureInventoryIds();
function money(v){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(Number(v)||0)+' ₽'}
function shortMoney(v){v=Number(v)||0;if(v>=1000000){const n=v/1000000;return (Number.isInteger(n)?n:n.toFixed(1).replace('.',','))+'М ₽'}if(v>=1000){const n=v/1000;return (Number.isInteger(n)?n:n.toFixed(1).replace('.',','))+'К ₽'}return money(v)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function save(){localStorage.setItem('shirneyser_profile_v5',JSON.stringify(profile));localStorage.setItem('shirneyser_inventory_v5',JSON.stringify(inventory));localStorage.setItem('shirneyser_history_v5',JSON.stringify(history));localStorage.setItem('shirneyser_balance_v5',String(balance));localStorage.setItem('shirneyser_exp_v5',String(totalExp));localStorage.setItem('shirneyser_stats_v5',JSON.stringify(stats));render()}
function getLevelInfo(exp=totalExp){let level=1,need=10,prev=0;if(exp>=10){level=2;prev=10;need=10;while(exp>=prev+need){prev+=need;level++;need*=2}}return {level,prev,need,cur:Math.max(0,exp-prev),remaining:Math.max(0,prev+need-exp)}}
function addExp(n){totalExp+=Number(n)||0;save()}
function levelThreshold(level){let l=Math.max(1,Math.floor(Number(level)||1));l=Math.min(l,50);if(l===1)return 0;if(l===2)return 10;const v=20*Math.pow(2,l-3);return Number.isFinite(v)?Math.min(v,Number.MAX_SAFE_INTEGER):Number.MAX_SAFE_INTEGER}
function renderHeader(){const info=getLevelInfo();document.querySelector('#balance').textContent=money(balance);document.querySelector('#headName').textContent=profile?.name||'Гость';document.querySelector('#headLevel').textContent=`Ур. ${info.level} · ${totalExp} EXP`;}
function itemCard(x,withSell=false,selectable=false,i=0){const selected=selectable&&selectedUpgradeId===x.id;return `<div class="item ${selected?'up-selected':''}" ${selectable?`onclick="selectUpgrade(${i})"`:''} style="${selectable?'cursor:pointer':''}"><img src="${x.src}" alt="${esc(x.name)}"><div class="item-info"><div class="item-name">${esc(x.name)}</div><div class="item-meta"><span class="rarity ${x.cls||'common'}">${esc(x.rarity||'Комонка')}</span><br>Цена: ${money(x.price||0)}<br><span class="chance-pill">Шанс: ${Number(x.chance)||0}%</span></div>${selectable?`<button type="button" class="btn secondary upgrade-select" onclick="event.stopPropagation();selectUpgrade(${i})">${selected?'ВЫБРАНО':'ПОЛОЖИТЬ В АПГРЕЙДОР'}</button>`:''}${withSell?`<button class="btn danger" style="margin-top:8px;padding:9px" onclick="event.stopPropagation();sellItem('${x.id}')">ПРОДАТЬ</button>`:''}</div></div>`}
function render(){renderHeader();document.querySelector('#inv').innerHTML=inventory.length?inventory.map((x,i)=>itemCard(x,true)).join(''):'<div class="empty">Инвентарь пуст.</div>';document.querySelector('#invValue').textContent='Стоимость инвентаря: '+money(inventory.reduce((a,x)=>a+Number(x.price||0),0));renderUpgradeItems();renderDaily();renderQuests();renderProfile();}
function openScreen(id){document.querySelectorAll('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.s===id));document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));document.querySelector('#'+id).classList.add('active');if(id==='daily')renderDaily();if(id==='settings')renderQuests();if(id==='upgrade')renderUpgradeItems();if(id==='profile')renderProfile();scrollTo(0,0)}
document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>openScreen(b.dataset.s));
function showDetails(key){const c=CASES[key];if(!c)return;if(!c.items.length){toast('Этот кейс пока пуст. Добавь в него картинки — и он будет готов.');return}currentCaseKey=key;openCount=1;document.querySelectorAll('.count').forEach(x=>x.classList.toggle('sel',x.dataset.count==='1'));document.querySelector('#details').style.display='block';document.querySelector('#detailImg').src=c.src;document.querySelector('#detailName').textContent=c.name;document.querySelector('#detailName').className=c.cls;document.querySelector('#detailPrice').textContent=shortMoney(c.price);document.querySelector('#totalCost').textContent=shortMoney(c.price);document.querySelector('#caseItems').innerHTML=c.items.map(x=>itemCard(x)).join('');document.querySelector('#detailOpenBtn').textContent=`ОТКРЫТЬ «${c.name}»`;document.querySelector('#details').scrollIntoView({behavior:'smooth',block:'start'})}
document.querySelectorAll('.count').forEach(b=>b.onclick=()=>{openCount=+b.dataset.count;document.querySelectorAll('.count').forEach(x=>x.classList.remove('sel'));b.classList.add('sel');const c=CASES[currentCaseKey];document.querySelector('#totalCost').textContent=shortMoney(openCount*c.price)});
function toast(t){const el=document.querySelector('#detailToast');el.textContent=t;el.classList.add('show');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>el.classList.remove('show'),2200)}
function weightedDrop(items){const arr=items.filter(x=>Number(x.chance)>0);if(!arr.length)return items[0];const total=arr.reduce((a,x)=>a+Number(x.chance),0);if(total>=100){let r=Math.random()*total;for(const x of arr){r-=Number(x.chance);if(r<=0)return x}return arr[arr.length-1]}let r=Math.random()*100;for(const x of arr){r-=Number(x.chance);if(r<=0)return x}return arr[Math.floor(Math.random()*arr.length)]}
function reelHTML(winner,items){let cells=[];for(let i=0;i<20;i++)cells.push(items[Math.floor(Math.random()*items.length)]);cells[15]=winner;return `<div class="reel-wrap"><div class="pointer"></div><div class="reel-window"><div class="reel">${cells.map(x=>`<div class="reel-card"><img src="${x.src}"><span>${esc(x.name)}</span><em>${money(x.price)}</em></div>`).join('')}</div></div></div>`}
function playFrom(a){try{a.pause();a.currentTime=0;const p=a.play();if(p&&p.catch)p.catch(()=>{});}catch(e){}}
function startOpen(count){if(openingBusy)return;const c=CASES[currentCaseKey];if(!c||!c.items.length)return toast('В этом кейсе пока нет предметов');count=Math.max(1,Number(count||1));const cost=count*c.price;if(balance<cost){toast('Недостаточно средств');return}const caseAudio=document.querySelector('#caseAudio');caseAudio.loop=false;playFrom(caseAudio);openingBusy=true;currentOpenCost=cost;balance-=cost;stats.cases+=count;stats.spent+=cost;questStat('open15',count);questStat(c.key==='school'?'school':(c.key==='dvor'?'dvor':''),1);addExp(count);modal.classList.add('show');results.style.display='none';document.querySelector('#closeOpen').style.display='none';document.querySelector('#openTitle').textContent=count>1?`${c.name} ×${count}`:`${c.name}`;document.querySelector('#openStatus').textContent='Крутится…';reels.innerHTML='';const wins=[];for(let i=0;i<count;i++){const w=weightedDrop(c.items);wins.push({...w});reels.insertAdjacentHTML('beforeend',reelHTML(w,c.items));questStat(w.rarity==='Мифик'?'mythic':w.rarity==='Легендарная'?'legendary':'',1)}const reelEls=[...reels.querySelectorAll('.reel')];requestAnimationFrame(()=>reelEls.forEach(r=>{const wrap=r.parentElement;const target=wrap.clientWidth/2;const cardCenter=(15*117)+54;const distance=Math.max(0,cardCenter-target);r.style.transition='transform 6.5s cubic-bezier(.06,.78,.1,1)';r.style.transform=`translateX(-${distance}px)`;}));setTimeout(()=>finishOpen(wins,c),6750)}
function finishOpen(wins,c){openingBusy=false;try{const a=document.querySelector('#caseAudio');a.pause();a.currentTime=0}catch(e){}playFrom(document.querySelector('#caseDropAudio'));document.querySelector('#openStatus').textContent='Выпало! Выбери, что сделать с каждым предметом.';results.style.display='grid';const total=wins.reduce((a,w)=>a+Number(w.price||0),0);const cls=total>=currentOpenCost?'positive':'negative';const now=new Date().toISOString();wins.forEach(w=>history.unshift({time:now,caseName:c.name,casePrice:c.price,drop:{...w},profit:Number(w.price||0)>=c.price}));history=history.slice(0,100);stats.received+=total;results.innerHTML=wins.map((w,i)=>`<div class="result spin drop-reveal"><img src="${w.src}" alt="${esc(w.name)}"><h3>${esc(w.name)}</h3><p><span class="rarity ${w.cls||'common'}">${esc(w.rarity)}</span> · ${Number(w.chance)}%</p><p>${money(w.price)}</p><div class="result-actions"><button class="btn danger" onclick="sellDrop(${i})">ПРОДАТЬ</button><button class="btn" onclick="keepDrop(${i})">В ИНВЕНТАРЬ</button></div></div>`).join('')+`<div class="open-summary"><div class="open-summary-row"><span>Потрачено</span><b>${money(currentOpenCost)}</b></div><div class="open-summary-row"><span>Получено</span><b class="${cls}">${money(total)}</b></div></div>`;window.currentWins=wins;document.querySelector('#closeOpen').style.display='block';save()}
function sellDrop(i){const w=window.currentWins?.[i];if(!w||w.done)return;balance+=Number(w.price)||0;w.done=true;results.children[i].innerHTML='<div style="padding:45px 8px;font-weight:900;color:#7ee09a">ПРОДАНО<br>+'+money(w.price)+'</div>';save()}
function keepDrop(i){const w=window.currentWins?.[i];if(!w||w.done)return;inventory.push({...w,id:Date.now()+'_'+i+'_'+Math.random().toString(36).slice(2)});w.done=true;results.children[i].innerHTML='<div style="padding:45px 8px;font-weight:900;color:#f6c34f">ДОБАВЛЕНО<br>В ИНВЕНТАРЬ</div>';save()}
function closeOpening(){if(openingBusy)return;const wins=window.currentWins||[];wins.forEach(w=>{if(w&&!w.done){inventory.push({...w,id:Date.now()+'_'+Math.random().toString(36).slice(2)});w.done=true}});save();window.currentWins=[];modal.classList.remove('show');reels.innerHTML='';results.innerHTML='';render();toast('Не забранные дропы автоматически добавлены в инвентарь')}
function sellItem(id){const i=inventory.findIndex(x=>x.id===id);if(i<0)return;const x=inventory.splice(i,1)[0];balance+=Number(x.price)||0;save();toast('Предмет продан за '+money(x.price))}
function sellAll(){if(!inventory.length){toast('Инвентарь пуст');return}const sum=inventory.reduce((a,x)=>a+Number(x.price||0),0);inventory=[];balance+=sum;save();toast('Продано всё: +'+money(sum))}
function setAdminAlwaysWin(v){adminAlwaysWin=!!v;localStorage.setItem('shirneyser_admin_always_win',adminAlwaysWin?'1':'0');toast(adminAlwaysWin?'Всегда выигрыш включён':'Всегда выигрыш выключен')}
function adminLogin(){const box=document.querySelector('#adminbox');if(box.classList.contains('show')){box.classList.remove('show');return}const p=prompt('Введите пароль администратора');if(p===ADMIN_PASSWORD){box.classList.add('show');document.querySelector('#adminAlwaysWin').checked=adminAlwaysWin;toast('Админ-панель открыта')}else if(p!==null)toast('Неверный пароль')}
function grantMoney(){const n=Number(document.querySelector('#adminAmount').value);if(!Number.isFinite(n)||n<=0)return toast('Введите положительное число');balance+=n;document.querySelector('#adminAmount').value='';save();toast('Начислено '+money(n))}
function grantLevel(){const input=Number(document.querySelector('#adminLevel').value);if(!Number.isFinite(input)||input<1)return toast('Введите уровень от 1 до 50');const l=Math.min(50,Math.floor(input));totalExp=levelThreshold(l);document.querySelector('#adminLevel').value='';save();toast('Выдан уровень '+l)}
const musicToggle=document.querySelector('#musicToggle');music.loop=true;music.preload='auto';music.setAttribute('playsinline','');musicToggle.checked=localStorage.getItem('shirneyser_music_v2')==='on';
async function startMusic(){try{music.loop=true;music.volume=1;await music.play();localStorage.setItem('shirneyser_music_v2','on');return true}catch(e){toast('Нажми кнопку ещё раз для запуска музыки');return false}}
function stopMusic(){music.pause();localStorage.setItem('shirneyser_music_v2','off')}
musicToggle.onchange=()=>musicToggle.checked?startMusic().then(()=>toast('Музыка включена')):stopMusic();function toggleMusicButton(){if(music.paused)startMusic().then(ok=>ok&&toast('Музыка включена'));else{stopMusic();toast('Музыка выключена')}}
music.addEventListener('ended',()=>{if(musicToggle.checked){music.currentTime=0;startMusic()}});
function dateKey(d=new Date()){return d.toISOString().slice(0,10)}function yesterdayKey(){const d=new Date();d.setDate(d.getDate()-1);return dateKey(d)}
function giftState(){return JSON.parse(localStorage.getItem('shirneyser_gift_v2')||'{}')}
function renderDaily(){const s=giftState();let day=Number(s.day||1);if(s.last&&s.last!==dateKey()&&s.last!==yesterdayKey())day=1;document.querySelector('#giftDay').textContent='День '+day;document.querySelector('#giftRewards').innerHTML=gifts.map((v,i)=>`<div class="gift-step ${i+1===day?'current':''}"><b>День ${i+1}</b><span>${money(v)}</span></div>`).join('');const claimed=s.last===dateKey();document.querySelector('#giftClaim').disabled=claimed;document.querySelector('#giftClaim').textContent=claimed?'ПОДАРОК УЖЕ ПОЛУЧЕН':'ЗАБРАТЬ ПОДАРОК'}
function claimGift(){const s=giftState(),today=dateKey();if(s.last===today)return;let day=Number(s.day||1);if(s.last&&s.last!==yesterdayKey())day=1;const amount=gifts[day-1];balance+=amount;s.last=today;s.day=day===7?1:day+1;localStorage.setItem('shirneyser_gift_v2',JSON.stringify(s));save();renderDaily();toast('Получено '+money(amount))}
function ensureQuests(){const today=dateKey();let s=JSON.parse(localStorage.getItem('shirneyser_quests_v2')||'{}');if(s.date!==today){const base=Math.floor(new Date(today+'T00:00:00').getTime()/86400000);const patterns=[[0,1,2],[1,2,3],[2,3,4],[3,4,5],[4,5,0],[5,0,1],[0,2,4],[1,3,5]];s={date:today,ids:patterns[base%patterns.length],stats:{open15:0,mythic:0,legendary:0,login:1,school:0,dvor:0},claimed:{}};localStorage.setItem('shirneyser_quests_v2',JSON.stringify(s))}else if(!s.stats.login)s.stats.login=1;return s}
function questStat(id,n){if(!id)return;const s=ensureQuests();s.stats[id]=(s.stats[id]||0)+n;localStorage.setItem('shirneyser_quests_v2',JSON.stringify(s))}
function renderQuests(){const s=ensureQuests();document.querySelector('#quests').innerHTML=(s.ids||[]).map(i=>{const q=questPool[i],val=Math.min(q.target,Number(s.stats[q.id]||0)),done=val>=q.target,claimed=!!s.claimed[q.id];return `<div class="quest ${done?'done':''}"><div class="quest-top"><div class="quest-title">${done?'✅ ':''}${q.title}</div><div class="quest-reward">+${money(q.reward)}</div></div><div class="progress"><i style="width:${(val/q.target)*100}%"></i></div><div class="quest-top"><span class="subtle">${val}/${q.target}</span>${done&&!claimed?`<button class="btn" style="width:auto;padding:7px 12px" onclick="claimQuest('${q.id}')">ЗАБРАТЬ</button>`:claimed?'<span class="won">ПОЛУЧЕНО</span>':''}</div></div>`}).join('')}
function claimQuest(id){const s=ensureQuests(),q=questPool.find(x=>x.id===id);if(!q||Number(s.stats[id]||0)<q.target||s.claimed[id])return;balance+=q.reward;s.claimed[id]=1;localStorage.setItem('shirneyser_quests_v2',JSON.stringify(s));save();toast('Квест: +'+money(q.reward))}
// Апгрейдор: карточка выбирается по стабильному id, а победа определяется фактической финальной позицией колеса.
document.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>{upgradeChance=Number(b.dataset.up);document.querySelectorAll('[data-up]').forEach(x=>x.classList.remove('sel'));b.classList.add('sel');document.querySelector('#wheelPercent').textContent=upgradeChance+'%';document.querySelector('#multiplierText').textContent='При победе: ×'+multipliers[upgradeChance];document.querySelector('.upgrade-wheel').style.setProperty('--chance',upgradeChance+'%')});document.querySelector('.upgrade-wheel').style.setProperty('--chance',upgradeChance+'%');
function renderUpgradeItems(){const area=document.querySelector('#upgradeItems');const selected=selectedUpgradeId?inventory.find(x=>x.id===selectedUpgradeId):null;if(!selected)selectedUpgradeId=null;if(!inventory.length){area.innerHTML='<div class="empty">Сначала забери карточку из кейса в инвентарь.</div>';document.querySelector('#upgradeArea').style.display='none';return}area.innerHTML=inventory.map((x,i)=>itemCard(x,false,true,i)).join('');document.querySelector('#upgradeArea').style.display=selected?'grid':'none';if(selected){document.querySelector('#upgradeImg').src=selected.src;document.querySelector('#upgradeImg').style.display='block';document.querySelector('#wheelName').textContent=selected.name;}}
function selectUpgrade(i){const x=inventory[i];if(!x)return toast('Карточка не найдена');ensureInventoryIds();selectedUpgradeId=x.id;document.querySelector('#upgradeArea').style.display='grid';document.querySelector('#upgradeImg').src=x.src;document.querySelector('#upgradeImg').style.display='block';document.querySelector('#wheelName').textContent=x.name;document.querySelector('#upgradeResult').classList.remove('show');renderUpgradeItems();toast('Карточка положена в Апгрейдор: '+x.name)}
function toggleLightning(){lightningFast=!lightningFast;const btn=document.querySelector('#lightningToggle'),stage=document.querySelector('.upgrade-stage'),txt=document.querySelector('#upgradeSpeedText');btn.classList.toggle('active',lightningFast);stage.classList.toggle('fast',lightningFast);txt.textContent=lightningFast?'⚡ Быстро':'Медленно';toast(lightningFast?'Молния включена — быстро':'Молния выключена — медленно')}
function upgradeLandingFromRotation(rotationDeg){
  const normalized=((rotationDeg%360)+360)%360;
  return ((360-normalized)%360);
}
function showUpgradeSuccess(result,x,newPrice){
  result.innerHTML=`<div class="upgrade-result-box">
    <div class="success-pill">✨ УСПЕШНЫЙ АПГРЕЙД!</div>
    <div class="result-image-wrap drop-reveal"><img src="${x.src}" alt="${esc(x.name)}"></div>
    <div class="result-name">${esc(x.name)}</div>
    <div class="result-meta"><span class="result-chip win">⚡ ${upgradeChance}%</span><span class="result-chip">${money(newPrice)}</span></div>
    <div class="result-actions" style="grid-template-columns:1fr">
      <button class="btn take-win" onclick="takeUpgradeWin()">ЗАБРАТЬ В ИНВЕНТАРЬ</button>
      <button class="btn danger sell-win" onclick="sellUpgradeWin()">ПРОДАТЬ ЗА ${money(newPrice)}</button>
    </div>
    <div class="result-note">Карточка уже сохранена как ожидаемый выигрыш — она не потеряется при случайном закрытии.</div>
  </div>`;
  result.classList.add('show');
}
function showUpgradeLoss(result){
  result.innerHTML=`<div class="upgrade-result-box"><div class="lost" style="font-size:24px">❌ АПГРЕЙД НЕ УДАЛСЯ</div><div class="drop-reveal"><p class="muted">Стрелка остановилась вне жёлтой области.</p><div style="font-size:50px">🔥</div><p class="lost">Карточка сгорела.</p></div><button class="close" onclick="closeUpgradeResult()">ЗАКРЫТЬ</button></div>`;
  result.classList.add('show');
}
function startUpgrade(){
  ensureInventoryIds();
  const selected=selectedUpgradeId?inventory.find(x=>x.id===selectedUpgradeId):null;
  if(!selected)return toast('Сначала положи карточку в Апгрейдор');
  const idx=inventory.findIndex(x=>x.id===selected.id);
  if(idx<0){selectedUpgradeId=null;renderUpgradeItems();return toast('Карточка больше не в инвентаре')}
  const startBtn=document.querySelector('#upgradeStart');
  startBtn.disabled=true;
  const result=document.querySelector('#upgradeResult');
  result.classList.remove('show');
  const wheel=document.querySelector('.upgrade-wheel');
  const chanceDeg=upgradeChance*3.6;

  // ВАЖНО: жёлтая зона вращается вместе с колесом, а стрелка остаётся неподвижной сверху.
  // Поэтому физическая победа возможна только тогда, когда после финального вращения
  // жёлтый сектор реально находится под стрелкой. Один и тот же finalRemainder
  // используется и для анимации, и для определения результата — никакого второго рандома.
  let finalRemainder;
  if(adminAlwaysWin){
    const minR=Math.max(0,360-chanceDeg+0.25);
    const maxR=Math.min(360,359.75);
    finalRemainder=minR+Math.random()*Math.max(0,maxR-minR);
  }else{
    finalRemainder=Math.random()*360;
  }
  const finalDeg=360*20+finalRemainder;
  const physicalLanding=upgradeLandingFromRotation(finalRemainder);
  const physicalWin=physicalLanding>=0 && physicalLanding<=chanceDeg+0.000001;

  const audio=document.querySelector(lightningFast?'#upgradeFastAudio':'#upgradeSpinAudio');
  audio.loop=false;
  playFrom(audio);

  const duration=lightningFast?2600:6500;
  wheel.getAnimations().forEach(a=>a.cancel());
  wheel.style.transition='none';
  wheel.style.transform='rotate(0deg)';
  // Форсируем применение нулевого положения, чтобы каждый новый запуск начинался одинаково.
  void wheel.offsetWidth;
  wheel.style.transition=`transform ${duration}ms cubic-bezier(.06,.72,.08,1)`;
  wheel.style.transform=`rotate(${finalDeg}deg)`;

  // Не используем animation.finished: в некоторых Android WebView он срабатывает нестабильно.
  // Таймер завершения соответствует той же анимации, поэтому карточка никогда не теряется.
  const runId=(window.__upgradeRunId||0)+1;
  window.__upgradeRunId=runId;
  setTimeout(()=>{
    if(window.__upgradeRunId!==runId)return;
    wheel.style.transition='none';
    wheel.style.transform=`rotate(${finalDeg}deg)`;
    try{audio.pause();audio.currentTime=0}catch(e){}

    const x=inventory.splice(idx,1)[0];
    if(!x){
      startBtn.disabled=false;
      selectedUpgradeId=null;
      renderUpgradeItems();
      return toast('Не удалось получить карточку. Попробуй ещё раз.');
    }

    if(physicalWin){
      const mult=multipliers[upgradeChance];
      const newPrice=Number((Number(x.price||0)*mult).toFixed(2));
      x.price=newPrice;
      // Победитель сразу возвращается в инвентарь и одновременно сохраняется как ожидаемый результат.
      // Поэтому даже если окно результата закроется или WebView перезапустится, предмет не пропадёт.
      pendingUpgradeWin=x;
      if(!inventory.some(it=>it.id===x.id))inventory.push(x);
      localStorage.setItem('shirneyser_pending_upgrade_v1',JSON.stringify(x));
      showUpgradeSuccess(result,x,newPrice);
      playFrom(document.querySelector('#upgradeWinAudio'));
      toast('УСПЕШНЫЙ АПГРЕЙД! Карточка добавлена в инвентарь');
    }else{
      pendingUpgradeWin=null;
      localStorage.removeItem('shirneyser_pending_upgrade_v1');
      showUpgradeLoss(result);
      playFrom(document.querySelector('#upgradeLossAudio'));
    }
    selectedUpgradeId=null;
    startBtn.disabled=false;
    save();
    // save() вызывает render(), но результат уже показан и остаётся поверх экрана.
    result.classList.add('show');
  },duration+120);
}
function takeUpgradeWin(){
  if(!pendingUpgradeWin)return;
  ensureInventoryIds();
  if(!inventory.some(x=>x.id===pendingUpgradeWin.id)) inventory.push(pendingUpgradeWin);
  const price=Number(pendingUpgradeWin.price||0);
  localStorage.removeItem('shirneyser_pending_upgrade_v1');
  pendingUpgradeWin=null;
  save();
  document.querySelector('#upgradeResult').classList.remove('show');
  renderUpgradeItems();
  toast('Карточка добавлена в инвентарь: '+money(price));
}
function sellUpgradeWin(){
  if(!pendingUpgradeWin)return;
  const x=pendingUpgradeWin;
  const i=inventory.findIndex(it=>it.id===x.id);
  if(i>=0)inventory.splice(i,1);
  balance+=Number(x.price||0);
  localStorage.removeItem('shirneyser_pending_upgrade_v1');
  pendingUpgradeWin=null;
  save();
  document.querySelector('#upgradeResult').classList.remove('show');
  renderUpgradeItems();
  toast('Продано за '+money(x.price));
}
function closeUpgradeResult(){
  if(pendingUpgradeWin)takeUpgradeWin();
  else {document.querySelector('#upgradeResult').classList.remove('show');renderUpgradeItems()}
}
function restorePendingUpgrade(){
  try{
    const raw=localStorage.getItem('shirneyser_pending_upgrade_v1');
    if(!raw)return;
    const x=JSON.parse(raw);
    if(x&&x.id&&x.src&&x.name){pendingUpgradeWin=x;setTimeout(()=>{const result=document.querySelector('#upgradeResult');showUpgradeSuccess(result,x,Number(x.price||0));},0)}
    else localStorage.removeItem('shirneyser_pending_upgrade_v1');
  }catch(e){localStorage.removeItem('shirneyser_pending_upgrade_v1')}
}
// Profile / registration
function renderChoices(containerId,selected){document.querySelector('#'+containerId).innerHTML=nicknames.map(n=>`<button type="button" class="choice ${n===selected?'sel':''}" onclick="selectNick('${containerId}','${esc(n)}')">${esc(n)}</button>`).join('')}
function selectNick(containerId,n){document.querySelectorAll('#'+containerId+' .choice').forEach(b=>b.classList.toggle('sel',b.textContent===n));document.querySelector('#'+containerId).dataset.selected=n;if(containerId==='regChoices')stopSiren()}
function startSiren(message){const e=document.querySelector('#sirenAudio'),stop=document.querySelector('#sirenStop'),err=document.querySelector('#regError');if(err)err.textContent=message||'';stop.style.display='block';try{e.currentTime=0;e.loop=true;const p=e.play();if(p&&p.catch)p.catch(()=>{})}catch(x){}}function stopSiren(){const e=document.querySelector('#sirenAudio');e.pause();try{e.currentTime=0}catch(x){}document.querySelector('#sirenStop').style.display='none'}function registerProfile(){const name=document.querySelector('#regName').value.trim(),age=Number(document.querySelector('#regAge').value),nick=document.querySelector('#regChoices').dataset.selected;if(!name){startSiren('Заполни имя');return}if(!age||age<1||age>120){startSiren('Неверный возраст');return}if(!nick){startSiren('Выбери прозвище');return}stopSiren();profile={name,age,nickname:nick,photo:''};localStorage.setItem('shirneyser_profile_v5',JSON.stringify(profile));document.querySelector('#registerModal').classList.remove('show');render();toast('Профиль создан!')}
function editProfile(){if(!profile)return;document.querySelector('#editName').value=profile.name||'';document.querySelector('#editAge').value=profile.age||'';renderChoices('editChoices',profile.nickname||nicknames[0]);document.querySelector('#editChoices').dataset.selected=profile.nickname||nicknames[0];document.querySelector('#editModal').classList.add('show')}
function saveEditedProfile(){const name=document.querySelector('#editName').value.trim(),age=Number(document.querySelector('#editAge').value),nick=document.querySelector('#editChoices').dataset.selected;if(!name||!age||age<1||age>120||!nick)return toast('Заполни профиль полностью');profile={...profile,name,age,nickname:nick};save();document.querySelector('#editModal').classList.remove('show');toast('Профиль сохранён')}
function closeEditProfile(){document.querySelector('#editModal').classList.remove('show')}
function choosePhoto(){document.querySelector('#photoInput').click()}
document.querySelector('#photoInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;const reader=new FileReader();reader.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas'),max=320,scale=Math.min(1,max/Math.max(im.width,im.height));c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));c.getContext('2d').drawImage(im,0,0,c.width,c.height);profile.photo=c.toDataURL('image/jpeg',.78);save();toast('Фотография профиля установлена')};im.src=reader.result};reader.readAsDataURL(f);e.target.value=''})
function renderProfile(){if(!profile)return;const info=getLevelInfo();document.querySelector('#profileName').textContent=profile.name;document.querySelector('#profileNick').textContent='@'+profile.nickname;document.querySelector('#profileAvatar').src=profile.photo||'assets/game-logo.png';document.querySelector('#profileLevel').textContent='Уровень '+info.level;document.querySelector('#profileExpText').textContent=`${info.cur} / ${info.need} EXP`;document.querySelector('#profileExpBar').style.width=Math.min(100,(info.cur/info.need)*100)+'%';document.querySelector('#statCases').textContent=stats.cases||0;document.querySelector('#statWins').textContent=history.length;document.querySelector('#statSpent').textContent=money(stats.spent||0);document.querySelector('#statReceived').textContent=money(stats.received||0);const best=history.reduce((a,h)=>!a||Number(h.drop.price)>Number(a.drop.price)?h:a,null);document.querySelector('#bestDrop').innerHTML=best?`<img src="${best.drop.src}"><div><h3>${esc(best.drop.name)}</h3><div class="rarity ${best.drop.cls}">${esc(best.drop.rarity)}</div><div class="best-price">${money(best.drop.price)}</div></div>`:'<div class="empty" style="width:100%">Пока нет открытий.</div>';document.querySelector('#history').innerHTML=history.length?history.map((h,i)=>{const profit=!!h.profit;return `<div class="history-card ${profit?'profit':'loss'}"><div class="history-top"><div class="history-case">${esc(h.caseName)}</div><div class="history-status">${profit?'ОКУП':'НЕ ОКУП'} ${profit?'✓':'✕'}</div></div><div class="history-main"><img src="${h.drop.src}"><div><b>${esc(h.drop.name)}</b><small>${money(h.drop.price)}</small></div><div class="arrow">→<br><span style="font-size:9px;color:#778292">${money(h.casePrice)}</span></div></div></div>`}).join(''):'<div class="empty">История пока пустая. Открой первый кейс.</div>'}
// First launch registration
function ensureProfile(){if(!profile){renderChoices('regChoices',nicknames[0]);document.querySelector('#regChoices').dataset.selected='';document.querySelector('#registerModal').classList.add('show')}else stopSiren()}
ensureQuests();questStat('login',1);render();restorePendingUpgrade();document.addEventListener('pointerdown',()=>{[...document.querySelectorAll('audio')].forEach(a=>{try{a.load()}catch(e){}})},{once:true});ensureProfile();
