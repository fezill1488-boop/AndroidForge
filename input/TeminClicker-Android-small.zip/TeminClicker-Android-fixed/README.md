# TeminClicker Android

HTML-игра упакована в Android WebView. Музыка хранится локально в `app/src/main/assets/music.mp3`.

## Сборка без ПК
Проект содержит GitHub Actions workflow. После загрузки файлов в репозиторий GitHub откройте **Actions → Build TeminClicker APK → Run workflow**. Готовый `app-debug.apk` появится в **Artifacts**.

Важно: для загрузки через телефон можно распаковать этот архив и загрузить содержимое проекта. Сам архив иногда не принимается мобильной страницей GitHub.
