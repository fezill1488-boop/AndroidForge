OSINT Android WebView project

This is an Android Gradle project wrapping the OSINT web app in a native Android WebView.
Main page: app/src/main/assets/index.html
Application ID: com.osint.android
Build: assembleDebug

Upload the CONTENTS of this folder as a ZIP to AndroidForge. Do not upload the original HTML-only ZIP.
